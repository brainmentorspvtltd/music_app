import logo from './logo.svg';
import './App.css';
import { MusicPage } from './pages/MusicPage';

function App() {
  return (
   <MusicPage/>
  );
}

export default App;
