export const Title = ()=>{
    return (<h1 className='alert alert-info text-center'>Music App</h1>)
}