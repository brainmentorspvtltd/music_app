export const Search = ()=>{
    return (
     <>  
    <input className='form-control' type='text' placeholder="Type to Search"/>
    <button className='btn btn-primary'>Search</button>
    </> 
    );
}